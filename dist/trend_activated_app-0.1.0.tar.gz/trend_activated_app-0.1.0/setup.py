# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['trend_activated_app', 'trend_activated_app.src']

package_data = \
{'': ['*'],
 'trend_activated_app.src': ['.idea/.gitignore',
                             '.idea/.gitignore',
                             '.idea/.gitignore',
                             '.idea/.gitignore',
                             '.idea/inspectionProfiles/*',
                             '.idea/misc.xml',
                             '.idea/misc.xml',
                             '.idea/misc.xml',
                             '.idea/misc.xml',
                             '.idea/modules.xml',
                             '.idea/modules.xml',
                             '.idea/modules.xml',
                             '.idea/modules.xml',
                             '.idea/src.iml',
                             '.idea/src.iml',
                             '.idea/src.iml',
                             '.idea/src.iml']}

install_requires = \
['confluent-kafka>=2.0.2,<3.0.0',
 'ipython>=8.10.0,<9.0.0',
 'kafka-python>=2.0.2,<3.0.0',
 'pandas>=1.5.3,<2.0.0',
 'python-binance>=1.0.16,<2.0.0',
 'requests>=2.28.2,<3.0.0',
 'shared-memory-dict>=0.7.2,<0.8.0',
 'simple-websocket>=0.9.0,<0.10.0']

setup_kwargs = {
    'name': 'trend-activated-app',
    'version': '0.1.0',
    'description': '',
    'long_description': '# trend-activated-trailing-stop-loss-bot\nA Technical Analysis employing test of the Unicorn Binance Trailing Stop Loss Engine within Binance\'s Futures Exchange\n\n## Installation\nInstallation can take the form of either creating a Conda environment with the provided yml file or, alternatively \ncreating a Python virtual environment.\n\nTake note of either of the two following steps:\n\n### Conda Environment Creation\nMake sure to cd into the root directory of trend-activated-trailing-stop-loss-algo to then create a conda \nenvironment from the environment yaml file:\n```\nconda env create -f trend_activated_bot_env.yml\n```\nThen you can activate the newly created environment that now houses the project\'s dependencies:\n```\nconda activate trend_activated_algo_env\n```\n\n### Virtual Environment Creation\nYou can alternatively create/load a Python virtual environment from the root directory:\n```\n$ python3 -m venv trend_activated_bot_env\n$ source trend_activated_bot_env/bin/activate\n```\nHaving created this venv without a yml file, you will need to install the non-native libraries relied \nupon by this project, found within the requirements.txt file:\n```\n$ python3 -m pip install -r requirements.txt\n```\n\n### Remote Virtual Machine Use\nFor now we will want to set up a quick free tier virtual machine instance with Amazon AWS in order to interact with Binance. Instructions for doing so can be found [here](https://github.com/pablobendiksen/trend-activated-trailing-stop-loss-bot/tree/main/_REMOTE_LOGIN)\n\n## Execute\n```\n$ export API_KEY="aaa"\n$ export API_SECRET="bbb"\n$ ./main.py\n```\n',
    'author': 'UMB',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
